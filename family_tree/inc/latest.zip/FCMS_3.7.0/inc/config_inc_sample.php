<?php
$cfg_mysql_host = '';
$cfg_mysql_db   = ''; 
$cfg_mysql_user = ''; 
$cfg_mysql_pass = '';
